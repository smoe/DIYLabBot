"""Five static concept storeys from one relative floorplan, never a survey.

XY is presentation-scaled using an unmeasured room parameter. Z uses explicit
owner/presentation assumptions. The exchange marker is semantic geometry only.
"""
from pathlib import Path
import copy
import hashlib
import json
import math
import re

import assembly_model as assembly
import building_circulation as circulation
import building_roof as roof
import building_furnishings as furnishings
import building_exterior as exterior
import building_guards as guards
import building_alignment as alignment
import ground_floor_model as ground
import relative_floorplan as floor
import robot_spec as robot
import room_geometry_model as room
import tube_carrier_model as portable

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT/'model/building-stack.shared.json'
SCHEMA = ROOT/'model/building-stack.schema.json'
FORMAT = 'solidcraftbot.building-stack/1'
DRIVING = ('clear_height_mm', 'slab_thickness_mm')
digest = robot.digest
evaluate = robot.evaluate
numeric_shape = floor.numeric_shape


def require(condition, message):
    if not condition: raise ValueError(message)


def exact(value, fields, name):
    require(isinstance(value, dict) and set(value) == set(fields.split()), 'Invalid '+name+' fields')


def _spec(spec): return spec.get('_stack', spec)


def read(ref):
    exact(ref, 'source source_sha256', 'pinned reference')
    path = assembly.validate_reference(ref, root=ROOT); raw = path.read_bytes()
    require(hashlib.sha256(raw).hexdigest() == ref['source_sha256'], 'Source changed while reading')
    return json.loads(raw)


def stair_guard_profile(spec):
    source = _spec(spec)
    reference = source['circulation']['stairs'].get('guard_profile_ref')
    if reference is None:
        return None
    require(reference == '#/exterior' and 'exterior' in source,
            'Stair guards require the referenced exterior atrium profile')
    return guards.profile_from_exterior(source['exterior'])


def templates(spec):
    spec = _spec(spec)
    read(spec['sources']['floorplan'])
    plan = floor.load(assembly.validate_reference(spec['sources']['floorplan'], root=ROOT))
    require(plan['_source']['sha256'] == spec['sources']['floorplan']['source_sha256'], 'Canonical floorplan changed while loading')
    reference = read(spec['sources']['room_geometry'])
    require(reference.get('format') == 'solidcraftbot.room-geometry/1' and reference.get('units') == {'length': 'mm', 'angle': 'deg'}, 'Typed reference room geometry required')
    return plan, reference


def parameters(spec, overrides=None):
    raw = _spec(spec)
    require(not set(overrides or {})-set(DRIVING), 'Only height and slab assumptions may be overridden')
    values = {name: spec['parameters'][name]['expression'] for name in DRIVING} if '_stack' in spec else {}
    values.update(overrides or {})
    p = robot.parameters(raw, values)
    require(set(raw['parameters']) == set(DRIVING), 'Only independent vertical assumptions belong to the stack source')
    for name in DRIVING:
        definition = raw['parameters'][name]
        exact(definition, 'expression unit range basis description', 'vertical assumption')
        bounds = definition['range']
        require(definition['unit'] == 'mm' and len(bounds) == 2 and all(type(v) in (int, float) and math.isfinite(v) and v > 0 for v in bounds) and bounds[0] <= bounds[1], 'Positive finite mm bounds required')
        require(bounds[0] <= p[name] <= bounds[1], 'Vertical assumption outside declared range')
        require(definition['basis'] == ('owner_assumption' if name == 'clear_height_mm' else 'presentation_assumption'), 'Declare the basis of each vertical assumption')
    plan, reference = templates(raw); ref = raw['presentation_reference']; rp = room.parameters(reference)
    selected = next((a for a in plan['areas'] if a['id'] == ref['floorplan_area']), None)
    require(selected is not None and selected['kind'] == 'room', 'Existing room area required for presentation proportion')
    polygon = floor.outline(plan, selected); extent = max(x for x, y in polygon)-min(x for x, y in polygon)
    require(extent > 0, 'Reference area has no X extent')
    for key in ('width_parameter', 'wall_thickness_parameter', 'door_height_parameter'):
        name = ref[key]
        require(name in rp and reference['parameters'][name]['unit'] == 'mm' and rp[name] > 0, 'Positive mm source parameter required')
    p.update({'display_scale': rp[ref['width_parameter']]/extent, 'display_height': p['clear_height_mm'],
              'display_thickness': rp[ref['wall_thickness_parameter']], 'display_floor_depth': p['slab_thickness_mm'],
              'door_height_mm': rp[ref['door_height_parameter']], 'reference_width_mm': rp[ref['width_parameter']],
              'floor_pitch_mm': p['clear_height_mm']+p['slab_thickness_mm']})
    require(0 < p['door_height_mm'] < p['clear_height_mm'], 'Presentation door must leave a lintel under the assumed clear height')
    return p


def validate(spec):
    spec = _spec(spec); leading = {k: v for k, v in spec.items() if k not in {'_source', 'exterior', 'alignment', 'plan_variants', 'atrium_access', 'room_signs'}}
    exact(leading, 'format id sources calibration parameters presentation_reference levels atrium concept_exchange circulation roof qualification limitations', 'building stack')
    require(spec['format'] == FORMAT and spec['calibration'] is None, 'Uncalibrated building concept required')
    require(isinstance(spec['id'], str) and re.fullmatch('[A-Za-z][A-Za-z0-9_]*', spec['id']), 'Stable stack ID required')
    exact({k: v for k, v in spec['sources'].items() if k not in {'furnishings', 'laboratories', 'microscopy', 'kitchenette', 'monitor_wall', 'seminar_room'}}, 'floorplan room_geometry ground_floor basement', 'stack sources')
    ref = spec['presentation_reference']
    exact(ref, 'width_parameter wall_thickness_parameter door_height_parameter floorplan_area extent_axis basis', 'presentation reference')
    require(ref['extent_axis'] == 'x' and ref['basis'] == 'unmeasured_concept_proportion', 'Presentation proportion is not metric calibration')
    require([level['id'] for level in spec['levels']] == ['KG', 'EG', 'OG1', 'OG2', 'OG3'], 'Five ordered concept storeys required')
    for level in spec['levels']:
        exact(level, 'id label', 'level instance')
        require(isinstance(level['label'], str) and level['label'], 'Level label required')
    exact(spec['atrium'], 'area floor_levels', 'atrium override')
    require(spec['atrium']['floor_levels'] == ['EG'], 'Only the ground-storey atrium receives a floor')
    marker = spec['concept_exchange']
    exact(marker, 'id footprint_fraction color opacity status', 'semantic marker')
    require(marker['id'] == 'ConceptExchange' and marker['status'] == 'semantic_visualization_only', 'Marker is not hardware or a transport model')
    require(type(marker['footprint_fraction']) in (int, float) and math.isfinite(marker['footprint_fraction']) and 0 < marker['footprint_fraction'] < 1, 'Interior marker fraction required')
    require(type(marker['opacity']) in (int, float) and math.isfinite(marker['opacity']) and 0 < marker['opacity'] < 1 and re.fullmatch('#[0-9a-fA-F]{6}', marker['color']), 'Transparent semantic marker required')
    exact(spec['qualification'], 'metric_scale_known surveyed_heights structural_qualified transport_implemented trajectory_implemented hardware_executed fire_safety_qualified', 'qualification')
    require(all(value is False for value in spec['qualification'].values()), 'Concept assumptions do not qualify a real building or transport system')
    require(isinstance(spec['limitations'], list) and spec['limitations'] and all(isinstance(text, str) and text for text in spec['limitations']), 'Explicit text limitations required')
    p = parameters(spec); plan, reference = templates(spec)
    validate_plan_variants(spec, plan)
    validate_atrium_access(spec, plan)
    atrium_polygon(spec, plan)
    marker_polygon(spec, atrium_polygon(spec, plan))
    circulation.validate_source(spec['circulation'])
    interfaces(spec, p)
    return spec


def load(path=SOURCE):
    path = Path(path).resolve(); raw = path.read_bytes(); spec = json.loads(raw)
    validate(spec); sha = hashlib.sha256(raw).hexdigest()
    require(digest(path) == sha, 'Stack source changed while loading')
    spec['_source'] = {'path': str(path), 'sha256': sha}
    return spec


def atrium_polygon(spec, plan):
    area = next((a for a in plan['areas'] if a['id'] == spec['atrium']['area']), None)
    require(area is not None and area['kind'] == 'void', 'Existing source void area required')
    return floor.outline(plan, area)


def marker_polygon(spec, polygon):
    low = [min(p[i] for p in polygon) for i in (0, 1)]; high = [max(p[i] for p in polygon) for i in (0, 1)]
    half = [(high[i]-low[i])*spec['concept_exchange']['footprint_fraction']/2 for i in (0, 1)]
    center = [(a+b)/2 for a, b in zip(low, high)]
    def rectangle(point):
        x, y = point; w, h = half
        return [[x-w, y-h], [x+w, y-h], [x+w, y+h], [x-w, y+h]]
    def safe(points):
        if any(floor.point_membership(p, polygon) != 1 for p in points): return False
        for a, b in zip(points, points[1:]+points[:1]):
            for c, d in zip(polygon, polygon[1:]+polygon[:1]):
                if floor.side(a, b, c)*floor.side(a, b, d) == -1 and floor.side(c, d, a)*floor.side(c, d, b) == -1: return False
        return True
    candidates = [center]+sorted([[low[0]+(i+.5)*(high[0]-low[0])/21, low[1]+(j+.5)*(high[1]-low[1])/21] for j in range(21) for i in range(21)], key=lambda point: math.dist(point, center))
    result = next((rectangle(point) for point in candidates if safe(rectangle(point))), None)
    require(result is not None, 'Declared marker rectangle does not fit strictly inside the source atrium')
    return result


def validate_plan_variants(spec, plan):
    """Owner corrections to upper-storey use/openings; no copied plan geometry."""
    variants = _spec(spec).get('plan_variants', [])
    require(isinstance(variants, list), 'Plan variants must be a list')
    areas = {area['id']: area for area in plan['areas']}
    walls = {wall['id']: wall for wall in plan['walls']}
    openings = {opening['id']: opening for opening in plan['openings']}
    incidence = {name: {area['id'] for area in plan['areas'] if any(edge['wall'] == name for edge in area['boundary'])} for name in walls}
    raw = _spec(spec)
    protected = {raw['circulation']['elevator']['area'], *[item['area'] for item in raw['circulation']['stairs']['instances']]}
    ids, bindings = set(), set()
    for variant in variants:
        exact(variant, 'id levels area_overrides wall_overrides disabled_openings basis', 'plan variant')
        require(isinstance(variant['id'], str) and re.fullmatch('[A-Za-z][A-Za-z0-9_]*', variant['id']) and variant['id'] not in ids, 'Unique plan variant ID required')
        ids.add(variant['id'])
        selected = variant['levels']
        require(isinstance(selected, list) and selected and len(selected) == len(set(selected)) and set(selected) <= {'OG1', 'OG2', 'OG3'}, 'Plan variants support explicit upper-storey levels only')
        require(isinstance(variant['basis'], str) and variant['basis'], 'Plan variant needs an explicit owner/assumption basis')
        require(isinstance(variant['area_overrides'], dict) and isinstance(variant['wall_overrides'], dict), 'Reference-based plan overrides required')
        for name, change in variant['area_overrides'].items():
            exact(change, 'kind label', 'area use override')
            require(name in areas and name not in protected and areas[name]['kind'] in {'room', 'unknown'}, 'Only existing non-core rooms or unknown areas may receive a use override')
            require(change['kind'] in {'corridor', 'room'} and isinstance(change['label'], str) and change['label'], 'Explicit room or corridor use and label required')
        for name, kind in variant['wall_overrides'].items():
            require(name in walls and kind == 'open_boundary' and len(incidence[name]) == 2 and not incidence[name] & protected, 'Only a referenced non-core internal boundary may be opened')
        disabled = variant['disabled_openings']
        require(isinstance(disabled, list) and len(disabled) == len(set(disabled)), 'Unique disabled opening references required')
        for name in disabled:
            require(name in openings and openings[name]['kind'] == 'door' and not incidence[openings[name]['wall']] & protected, 'Only an existing non-core doorway may be disabled')
        for level in selected:
            for kind, names in [('area', variant['area_overrides']), ('wall', variant['wall_overrides']), ('opening', disabled)]:
                for name in names:
                    key = (level, kind, name)
                    require(key not in bindings, 'Conflicting plan variant bindings')
                    bindings.add(key)


def apply_plan_variants(spec, plan, level_id):
    validate_plan_variants(spec, plan)
    selected = [variant for variant in _spec(spec).get('plan_variants', []) if level_id in variant['levels']]
    if not selected:
        return plan
    result = copy.deepcopy(plan)
    for variant in selected:
        for area in result['areas']:
            area.update(variant['area_overrides'].get(area['id'], {}))
        for wall in result['walls']:
            if wall['id'] in variant['wall_overrides']:
                wall['kind'] = variant['wall_overrides'][wall['id']]
        result['openings'] = [opening for opening in result['openings'] if opening['id'] not in variant['disabled_openings']]
        result['provenance']['notes'].append('Building-only owner correction: '+variant['id'])
    floor.validate(result)
    return result


def validate_atrium_access(spec, plan):
    access = _spec(spec).get('atrium_access')
    if access is None:
        return
    exact(access, 'id plan_variant corridor_area atrium_area', 'atrium access anchor')
    require(isinstance(access['id'], str) and re.fullmatch('[A-Za-z][A-Za-z0-9_]*', access['id']), 'Stable atrium access ID required')
    variant = next((item for item in _spec(spec).get('plan_variants', []) if item['id'] == access['plan_variant']), None)
    require(variant is not None and variant['area_overrides'], 'Atrium access needs a declared plan variant')
    areas = {area['id']: area for area in plan['areas']}
    require(access['corridor_area'] in areas and areas[access['corridor_area']]['kind'] == 'corridor'
            and access['atrium_area'] == _spec(spec)['atrium']['area'], 'Referenced corridor and atrium required')
    selected = set(variant['area_overrides'])
    incidence = {wall['id']: {area['id'] for area in plan['areas'] if any(edge['wall'] == wall['id'] for edge in area['boundary'])} for wall in plan['walls']}
    opened = set(variant['wall_overrides'])
    entries = {name for name in opened if access['corridor_area'] in incidence[name] and incidence[name] & selected}
    guards = {name for name in opened if access['atrium_area'] in incidence[name] and incidence[name] & selected}
    internal = {name for name, adjacent in incidence.items() if len(adjacent & selected) == 2}
    require(entries and guards and internal <= opened, 'Alcove must connect its source areas, corridor entry and atrium edge')
    require(guards <= set(_spec(spec).get('exterior', {}).get('guard_boundaries', [])), 'Every open alcove-to-atrium edge requires the common railing')


def atrium_access_anchors(spec, plan, level_plans, p):
    """Resolve one environmental anchor per supported storey, without furniture."""
    access = _spec(spec).get('atrium_access')
    if access is None:
        return {}
    validate_atrium_access(spec, plan)
    variant = next(item for item in _spec(spec)['plan_variants'] if item['id'] == access['plan_variant'])
    names = set(variant['area_overrides'])
    incidence = {wall['id']: {area['id'] for area in plan['areas'] if any(edge['wall'] == wall['id'] for edge in area['boundary'])} for wall in plan['walls']}
    entries = [name for name in variant['wall_overrides'] if access['corridor_area'] in incidence[name] and incidence[name] & names]
    guards = [name for name in variant['wall_overrides'] if access['atrium_area'] in incidence[name] and incidence[name] & names]
    return {level: {'id': access['id'], 'level_id': level, 'plan': level_plans[level],
                    'area_refs': list(variant['area_overrides']), 'entry_boundary_ids': entries,
                    'guard_boundary_ids': guards, 'guard_post_mm': _spec(spec)['exterior']['guard_post_mm']}
            for level in variant['levels']}


def compile_furnishings(spec, plan, p, levels, bases):
    """Compose numbered rooms and anchor-bound non-room seating from one catalog."""
    plans = {name: value[0] for name, value in bases.items()}
    result = furnishings.compile(spec['sources']['furnishings'], plan, p, levels, level_plans=plans)
    source = furnishings.read(spec['sources']['furnishings'])
    groups = source.get('atrium_seating', [])
    require(isinstance(groups, list), 'Atrium seating templates must be a list')
    if groups:
        import atrium_seating
        catalog = furnishings.read(source['catalog'])
        anchors = atrium_access_anchors(spec, plan, plans, p)
        z = {level['id']: level['z_mm'] for level in levels}
        result['seating_groups'] = []
        seen = set()
        for group in groups:
            atrium_seating.validate(group)
            require(group['id'] not in seen, 'Unique atrium seating template IDs required')
            seen.add(group['id'])
            for level in group['levels']:
                require(level in anchors, 'Seating requires an actual access anchor on its storey')
                extra = atrium_seating.compile(catalog, group, anchors[level], p, z[level])
                for key in ('components', 'bodies', 'operations', 'body_ids'):
                    result[key].extend(extra[key])
                result['seating_groups'].append(extra['interface'])
        for key in ('components', 'bodies', 'operations'):
            ids = [item['id'] for item in result[key]]
            require(len(ids) == len(set(ids)), 'Duplicate combined furnishing '+key+' identity')
    return result


def level_plan(spec, level_id):
    """Resolve the actual registered EG once; upper floors reuse canonical F03."""
    raw = _spec(spec)
    if level_id in {'EG', 'KG'}:
        ref = raw['sources']['ground_floor' if level_id == 'EG' else 'basement']; read(ref)
        plan = ground.load(assembly.validate_reference(ref, root=ROOT))
        require(plan['_source']['sha256'] == ref['source_sha256'], 'EG source changed while loading')
        require(ground.raw_source(plan)['reference_floorplan'] == raw['sources']['floorplan'], 'EG registration must reference the same pinned canonical F03')
        canonical = templates(raw)[0]
        if level_id == 'KG':
            for core in [raw['circulation']['elevator']['area'], raw['circulation']['stairs']['instances'][0]['area']]:
                actual = floor.outline(plan, core); expected = floor.outline(canonical, core)
                require(abs(floor.signed_area(actual)-floor.signed_area(expected)) < 1e-10
                        and all(floor.point_membership(point, expected) == 0 for point in actual)
                        and all(floor.point_membership(point, actual) == 0 for point in expected),
                        'KG core differs from the shared vertical frame: '+core)
            walls = {wall['id']: wall for wall in plan['walls']}
            ref_walls = {wall['id']: wall for wall in canonical['walls']}
            for side in raw['circulation']['elevator']['sides'].values():
                name = side['wall']
                require(name in walls and walls[name]['kind'] == 'wall' and
                        {tuple(plan['vertices'][walls[name][key]]) for key in ('start', 'end')} ==
                        {tuple(canonical['vertices'][ref_walls[name][key]]) for key in ('start', 'end')},
                        'KG lift side differs from the shared port frame')
        if 'alignment' in raw:
            selected = [a for a in canonical['areas'] if a['id'] in raw['roof']['opaque_area_ids']]
            plan = alignment.register(plan, canonical, selected, raw['alignment'], level_id)
        return plan
    require(level_id in {'OG1', 'OG2', 'OG3'}, 'Unknown building level')
    return apply_plan_variants(raw, templates(raw)[0], level_id)


def _bases(spec, p):
    display = {k: p[k] for k in ('display_scale', 'display_height', 'display_thickness', 'display_floor_depth')}
    result = {}
    for level in spec['levels']:
        plan = level_plan(spec, level['id'])
        base = floor.expanded(plan, display); original = floor.interfaces(plan, display)
        # Only the stack projection changes: the public F03 trace stays intact.
        ext_area = spec['circulation']['external_stair']['area']
        incident = {}
        for area in plan['areas']:
            for ref in area['boundary']: incident.setdefault(ref['wall'], set()).add(area['id'])
        overlay_areas = {ext_area, 'ExternalLink'}
        omitted = {'Area_'+name for name in overlay_areas} | {'Wall_'+name for name, uses in incident.items() if uses and uses <= overlay_areas}
        base['bodies'] = [body for body in base['bodies'] if body['id'] not in omitted]
        base['operations'] = [op for op in base['operations'] if op['body'] not in omitted]
        original['opening_probes'] = [probe for probe in original['opening_probes'] if probe['target_body'] not in omitted]
        result[level['id']] = (plan, base, original)
    return result


def interfaces(spec, p):
    spec = _spec(spec); plan, _ = templates(spec); bases = _bases(spec, p)
    polygon = [[x*p['display_scale'], y*p['display_scale']] for x, y in atrium_polygon(spec, plan)]
    marker = [[x*p['display_scale'], y*p['display_scale']] for x, y in marker_polygon(spec, atrium_polygon(spec, plan))]
    levels = []; probes = []; voids = []; vertices = []; closures = []; variants = []
    original_probes = {probe['id']: probe for probe in floor.interfaces(plan, {key: p[key] for key in ('display_scale', 'display_height', 'display_thickness', 'display_floor_depth')})['opening_probes']}
    for index, level in enumerate(spec['levels']):
        chosen, base, originals = bases[level['id']]
        vertices.extend(chosen['vertices'].values())
        prefix = level['id']+'__'; z = (index-1)*p['floor_pitch_mm']; filled = level['id'] in spec['atrium']['floor_levels']
        walls = [b['id'] for b in base['bodies'] if b['role'] == 'relative_wall_display']
        slabs = [b['id'] for b in base['bodies'] if b['role'] == 'relative_area_display']
        floor_ids = [prefix+name for name in slabs]
        levels.append({**level, 'index': index, 'z_mm': z, 'slab_bottom_mm': z-p['slab_thickness_mm'], 'slab_top_mm': z, 'clear_top_mm': z+p['clear_height_mm'],
                       'template_source': spec['sources']['basement' if level['id'] == 'KG' else 'ground_floor' if level['id'] == 'EG' else 'floorplan']['source'], 'template_id': chosen['id'],
                       'atrium_floor_filled': filled, 'wall_bodies': [prefix+name for name in walls], 'floor_bodies': floor_ids})
        if level['id'].startswith('OG'):
            voids.append({'id': level['id']+'_AtriumVoid', 'kind': 'polygon_prism', 'points_mm': polygon, 'offset_mm': z-p['slab_thickness_mm'], 'depth_mm': p['slab_thickness_mm'], 'target_bodies': floor_ids})
        opening_by_id = {opening['id']: opening for opening in chosen['openings']}
        for probe in originals['opening_probes']:
            value = {**copy.deepcopy(probe), 'id': prefix+probe['id'], 'target_body': prefix+probe['target_body'], 'offset_mm': z+probe['offset_mm']}
            if opening_by_id[probe['id']]['kind'] == 'door': value['depth_mm'] = p['door_height_mm']-2*probe['display_inset_mm']
            require(value['depth_mm'] > 0, 'Presentation door cannot contain its inherited opening probe')
            probes.append(value)
        selected = [variant for variant in spec.get('plan_variants', []) if level['id'] in variant['levels']]
        chosen_walls = {wall['id']: wall for wall in chosen['walls']}
        for variant in selected:
            variants.append({'level_id': level['id'], **copy.deepcopy(variant)})
            for name in variant['disabled_openings']:
                probe = original_probes[name]
                wall_id = probe['target_body'].removeprefix('Wall_')
                # Removed doors on opened alcove boundaries need no material
                # witness; a disabled door in a retained wall must be filled.
                if chosen_walls[wall_id]['kind'] != 'wall':
                    continue
                value = {**copy.deepcopy(probe), 'id': prefix+'Closed_'+name,
                         'source_opening_id': name, 'target_body': prefix+probe['target_body'],
                         'offset_mm': z+probe['offset_mm'], 'depth_mm': p['door_height_mm']-2*probe['display_inset_mm'],
                         'expectation': 'filled'}
                value['expected_volume_mm3'] = abs(floor.signed_area(value['points_mm']))*value['depth_mm']
                closures.append(value)
    ground_probe = {'id': 'EG_AtriumCoverage', 'target_bodies': list(next(level for level in levels if level['id'] == 'EG')['floor_bodies']), 'expectation': 'union_filled', 'kind': 'polygon_prism', 'points_mm': polygon, 'offset_mm': -p['slab_thickness_mm'], 'depth_mm': p['slab_thickness_mm'], 'expected_volume_mm3': floor.signed_area(polygon)*p['slab_thickness_mm']}
    concept = {'body': spec['concept_exchange']['id'], 'points_mm': marker, 'offset_mm': 0, 'depth_mm': levels[-1]['clear_top_mm'], 'status': 'semantic_visualization_only'}
    data = {'levels': levels, 'clear_height_mm': p['clear_height_mm'], 'slab_thickness_mm': p['slab_thickness_mm'], 'floor_pitch_mm': p['floor_pitch_mm'],
            'ground_floor': {'id': bases['EG'][0]['id'], 'source': spec['sources']['ground_floor']['source']},
            'template_source': spec['sources']['floorplan']['source'], 'template_id': plan['id'], 'x_bounds_mm': [min(v[0] for v in vertices)*p['display_scale'], max(v[0] for v in vertices)*p['display_scale']],
            'y_bounds_mm': [min(v[1] for v in vertices)*p['display_scale'], max(v[1] for v in vertices)*p['display_scale']],
            'atrium_x_bounds_mm': [min(v[0] for v in polygon), max(v[0] for v in polygon)], 'atrium_polygon_mm': polygon,
            'atrium_y_bounds_mm': [min(v[1] for v in polygon), max(v[1] for v in polygon)],
            'opening_probes': probes, 'opening_closure_probes': closures, 'plan_variants': variants,
            'atrium_prisms': voids, 'ground_fill_probe': ground_probe, 'concept_marker': concept,
            'marker_body_ids': [concept['body']], 'wall_visibility_ids': [name for level in levels for name in level['wall_bodies']],
            'assumed_dimensions': copy.deepcopy(p), 'coordinate_meaning': {'xy': 'presentation_mm', 'z': 'assumed_mm'}, 'metric_scale_known': False,
            'structural_qualified': False, 'transport_implemented': False, 'trajectory_implemented': False, 'hardware_executed': False, 'fire_safety_qualified': False,
            'room_label_policy': 'EG uses the owner-labelled registered ground-floor source; OG labels are level-scoped F03 template references', 'limitations': list(spec['limitations'])}
    extra = circulation.compile(spec['circulation'], plan, p, levels, ground_plan=bases['EG'][0], ground_support_area=spec.get('alignment', {}).get('external_ground_support_area'), guard_profile=stair_guard_profile(spec))
    data['circulation'] = extra['interface']
    data['external_area_overlay'] = {'area': spec['circulation']['external_stair']['area'], 'full_slabs_omitted': True,
        'exclusive_boundary_walls_omitted': True, 'shared_facade_walls_preserved': True, 'source_unchanged': True}
    data['wall_visibility_ids'].extend(extra['interface']['wall_bridge_ids'])
    data['roof'] = roof.compile(spec['roof'], plan, p, levels)['interface']
    if 'furnishings' in spec['sources']:
        furnished = compile_furnishings(spec, plan, p, levels, bases)
        omitted = set(furnished['omitted_walls'])
        for level in levels:
            level['wall_bodies'] = [name for name in level['wall_bodies'] if name not in omitted]
        data['wall_visibility_ids'] = [name for name in data['wall_visibility_ids'] if name not in omitted]
        data['opening_probes'] = [probe for probe in data['opening_probes'] if probe['target_body'] not in omitted]
        data['furnishings'] = {key: furnished[key] for key in ('rooms', 'body_ids', 'omitted_walls')}
        if 'seating_groups' in furnished:
            data['furnishings']['seating_groups'] = furnished['seating_groups']
    anchors = atrium_access_anchors(spec, plan, {name: value[0] for name, value in bases.items()}, p)
    data['atrium_accesses'] = [{key: value for key, value in anchor.items() if key != 'plan'} for anchor in anchors.values()]
    data['atrium_access_floor_probes'] = []
    for level_id, anchor in anchors.items():
        chosen = anchor['plan']
        selected = [area for area in chosen['areas'] if area['id'] in anchor['area_refs']]
        edges = roof.outer_contour(chosen, selected)
        points = [[value*p['display_scale'] for value in chosen['vertices'][edge['start']]] for edge in edges]
        if floor.signed_area(points) < 0:
            points.reverse()
        datum = next(level['z_mm'] for level in levels if level['id'] == level_id)
        probe = {'id': level_id+'_'+anchor['id']+'_FloorSupport', 'kind': 'polygon_prism',
                 'points_mm': points, 'offset_mm': datum-p['slab_thickness_mm'], 'depth_mm': p['slab_thickness_mm'],
                 'target_bodies': [level_id+'__Area_'+name for name in anchor['area_refs']], 'expectation': 'union_filled'}
        probe['expected_volume_mm3'] = abs(floor.signed_area(points))*probe['depth_mm']
        data['atrium_access_floor_probes'].append(probe)
    if 'exterior' in spec:
        extension = exterior.compile(spec['exterior'], {v['id']: bases[v['id']][0] for v in levels}, p, levels, omitted_wall_ids=data.get('furnishings',{}).get('omitted_walls',()))
        ext = extension['interface']; omitted = set(ext['omitted_body_ids'])
        for level in levels: level['wall_bodies'] = [n for n in level['wall_bodies'] if n not in omitted]
        data['wall_visibility_ids'] = [n for n in data['wall_visibility_ids'] if n not in omitted]
        data['opening_probes'] = [v for v in data['opening_probes'] if v['target_body'] not in omitted]
        # Each leaf is checked separately against the same aperture, avoiding
        # irrelevant constructive leaf/jamb contacts in pairwise inspection.
        leaf_probes = []
        for probe in data['opening_probes']:
            if probe['id'] in ext['door_leaves']:
                leaf_probes.append({**copy.deepcopy(probe), 'id': 'LeafClear_'+probe['id'], 'target_body': ext['door_leaves'][probe['id']]})
        data['opening_probes'].extend(leaf_probes)
        data['opening_probes'].extend(ext.get('window_probes', []))
        data['exterior'] = ext
    if 'furnishings' in spec['sources']:
        for room in furnishings.read(spec['sources']['furnishings'])['rooms']:
            anchor = room.get('window_anchor')
            if anchor is not None:
                require(any(group['level_id'] == room['level'] and group['wall'] == anchor['wall_id']
                            for group in data.get('exterior', {}).get('side_window_groups', [])),
                        'A window-bound furniture layout requires a constructed exterior window on its storey')
    if 'laboratories' in spec['sources']:
        import building_laboratories
        laboratories = building_laboratories.compile(spec['sources']['laboratories'], {name: value[0] for name, value in bases.items()}, p, levels)
        data['laboratories'] = laboratories['laboratories']
        data['places'] = laboratories['places']
        if 'furnishings' in spec['sources']:
            data['places'].extend(building_laboratories.social_places(spec['sources']['furnishings'], furnished))
        data['topology'] = laboratories['topology']
    if 'microscopy' in spec['sources']:
        import building_microscopy
        data['microscopy'] = building_microscopy.compile(spec['sources']['microscopy'],
            {name: value[0] for name, value in bases.items()}, p, levels)['interface']
    if 'kitchenette' in spec['sources']:
        import building_kitchenette
        data['kitchenette'] = building_kitchenette.compile(spec['sources']['kitchenette'],
            {name: value[0] for name, value in bases.items()}, p, levels, spec['exterior']['doors'])['interface']
    if 'monitor_wall' in spec['sources']:
        import foyer_monitor_wall
        data['monitor_wall'] = foyer_monitor_wall.compile(spec['sources']['monitor_wall'],
            {name: value[0] for name, value in bases.items()}, p, levels)['interface']
    if 'seminar_room' in spec['sources']:
        import building_seminar
        seminar = building_seminar.compile(spec['sources']['seminar_room'], bases['EG'][0], p, levels,
                                           door_geometry=extension if 'exterior' in spec else None)
        data['seminar_room'] = seminar['interface']
        window_probes = seminar.get('window_probes', [])
        existing_windows = {group['target_body'] for group in data.get('exterior', {}).get('side_window_groups', [])}
        ground_walls = set(next(level['wall_bodies'] for level in levels if level['id'] == 'EG'))
        require(all(probe['target_body'] in ground_walls-existing_windows for probe in window_probes),
                'Seminar window apertures need uncovered EG wall bodies')
        data['opening_probes'].extend(window_probes)
    if 'room_signs' in spec:
        import building_room_signs
        omitted = set(data.get('furnishings', {}).get('omitted_walls', [])) | set(data.get('exterior', {}).get('omitted_body_ids', []))
        data['room_signs'] = building_room_signs.compile(spec['room_signs'], spec,
            {name: value[0] for name, value in bases.items()}, p, levels, omitted,
            door_geometry=extension if 'exterior' in spec else None)['interface']
    return data


def native_spec(spec, p):
    return {'id': _spec(spec)['id'], 'status': 'Concept building stack; XY presentation proportions and assumed Z, not measured building geometry',
            'parameters': {name: {'expression': value, 'unit': 'mm', 'range': [value, value], 'description': 'Unmeasured concept/presentation dimension; not building calibration'} for name, value in p.items()}, '_stack': _spec(spec)}


def expanded(spec, p):
    spec = _spec(spec); plan, _ = templates(spec); bases = _bases(spec, p); data = interfaces(spec, p)
    result = {'id': spec['id'], 'status': 'Static concept visualization only', 'parameters': native_spec(spec, p)['parameters'], 'components': [], 'bodies': [], 'operations': [], 'joints': []}
    for level in data['levels']:
        chosen, base, _ = bases[level['id']]
        doors = {'Opening_'+o['id'] for o in chosen['openings'] if o['kind'] == 'door'}
        prefix = level['id']+'__'; component = level['id']+'_Layer'
        result['components'].append({'id': component, 'grounded': True})
        for body in base['bodies']:
            role = 'concept_storey_wall' if body['role'] == 'relative_wall_display' else 'concept_storey_slab'
            result['bodies'].append({**copy.deepcopy(body), 'id': prefix+body['id'], 'component': component, 'role': role, 'source_body_id': body['id'], 'level_id': level['id']})
        for operation in base['operations']:
            shape = numeric_shape(operation['shape'], p)
            if operation['id'] in doors: shape['depth'] = p['door_height_mm']
            shape['offset'] += level['z_mm']
            result['operations'].append({**copy.deepcopy(operation), 'id': prefix+operation['id'], 'body': prefix+operation['body'], 'shape': shape})
    def prism(name, component, role, points, offset, depth, color, opacity=1):
        result['bodies'].append({'id': name, 'component': component, 'role': role, 'appearance': {'color': color, 'opacity': opacity}})
        result['operations'].append({'id': name+'_Profile', 'body': name, 'action': 'create', 'shape': {'kind': 'polygon_prism', 'plane': 'XY', 'points': points, 'offset': offset, 'depth': depth, 'fixed': True}})
    result['components'].append({'id': 'ConceptMarker', 'grounded': True}); marker = data['concept_marker']
    prism(marker['body'], 'ConceptMarker', 'semantic_exchange_marker', marker['points_mm'], marker['offset_mm'], marker['depth_mm'], spec['concept_exchange']['color'], spec['concept_exchange']['opacity'])
    extra = circulation.compile(spec['circulation'], plan, p, data['levels'], ground_plan=bases['EG'][0], ground_support_area=spec.get('alignment', {}).get('external_ground_support_area'), guard_profile=stair_guard_profile(spec))
    roof_geometry = roof.compile(spec['roof'], plan, p, data['levels'])
    for key in ('components', 'bodies', 'operations'):
        result[key].extend(extra[key]); result[key].extend(roof_geometry[key])
    if 'furnishings' in spec['sources']:
        furnished = compile_furnishings(spec, plan, p, data['levels'], bases)
        omitted = set(furnished['omitted_walls'])
        result['bodies'] = [body for body in result['bodies'] if body['id'] not in omitted]
        result['operations'] = [op for op in result['operations'] if op['body'] not in omitted]
        for key in ('components', 'bodies', 'operations'): result[key].extend(furnished[key])
    if 'exterior' in spec:
        extension = exterior.compile(spec['exterior'], {v['id']: bases[v['id']][0] for v in data['levels']}, p, data['levels'], omitted_wall_ids=data.get('furnishings',{}).get('omitted_walls',()))
        omitted = set(extension['interface']['omitted_body_ids'])
        for body in result['bodies']:
            if body['id'] in extension['interface'].get('surface_overrides', {}):
                body['appearance'] = extension['interface']['surface_overrides'][body['id']]
        result['bodies'] = [v for v in result['bodies'] if v['id'] not in omitted]
        result['operations'] = [v for v in result['operations'] if v['body'] not in omitted]
        for key in ('components', 'bodies', 'operations'): result[key].extend(extension[key])
    if 'laboratories' in spec['sources']:
        import building_laboratories
        laboratories = building_laboratories.compile(spec['sources']['laboratories'], {name: value[0] for name, value in bases.items()}, p, data['levels'])
        for key in ('components', 'bodies', 'operations'): result[key].extend(laboratories[key])
    if 'microscopy' in spec['sources']:
        import building_microscopy
        microscopy = building_microscopy.compile(spec['sources']['microscopy'],
            {name: value[0] for name, value in bases.items()}, p, data['levels'])
        for key in ('components', 'bodies', 'operations'): result[key].extend(microscopy[key])
    if 'kitchenette' in spec['sources']:
        import building_kitchenette
        kitchenette = building_kitchenette.compile(spec['sources']['kitchenette'],
            {name: value[0] for name, value in bases.items()}, p, data['levels'], spec['exterior']['doors'])
        for key in ('components', 'bodies', 'operations'): result[key].extend(kitchenette[key])
    if 'monitor_wall' in spec['sources']:
        import foyer_monitor_wall
        displays = foyer_monitor_wall.compile(spec['sources']['monitor_wall'],
            {name: value[0] for name, value in bases.items()}, p, data['levels'])
        for key in ('components', 'bodies', 'operations'): result[key].extend(displays[key])
    if 'seminar_room' in spec['sources']:
        import building_seminar
        seminar = building_seminar.compile(spec['sources']['seminar_room'], bases['EG'][0], p, data['levels'],
                                           door_geometry=extension if 'exterior' in spec else None)
        for key in ('components', 'bodies', 'operations'): result[key].extend(seminar[key])
    if 'room_signs' in spec:
        import building_room_signs
        omitted = set(data.get('furnishings', {}).get('omitted_walls', [])) | set(data.get('exterior', {}).get('omitted_body_ids', []))
        signs = building_room_signs.compile(spec['room_signs'], spec,
            {name: value[0] for name, value in bases.items()}, p, data['levels'], omitted,
            door_geometry=extension if 'exterior' in spec else None)
        for key in ('components', 'bodies', 'operations'): result[key].extend(signs[key])
    return result


def cases(spec): return [{'id': 'stacked'}]
def materialize(spec, case_id):
    require(case_id == 'stacked', 'Only the static five-storey stack is implemented'); return copy.deepcopy(spec)
def pose(spec, p, name=None):
    require(name in (None, 'stacked'), 'No building or transport motion is implemented'); return {}
def validate_pose(source, values):
    require(source['joints'] == [] and values == {}, 'Stack has no motion channels')
def samples(spec, p): return [{'id': 'stacked', 'values_mm': {}}]
def displacement(source, component, values):
    validate_pose(source, values); return [0, 0, 0]


def solidcraft_commands(spec, p):
    raw = _spec(spec)
    source = expanded(spec, p)
    import building_room_signs
    class Provider:
        SOURCE = Path(raw.get('_source', {}).get('path', __file__))
        expanded = staticmethod(lambda _spec, _p: building_room_signs.physical_source(source))
        pose = staticmethod(pose)
        samples = staticmethod(samples)
    commands = portable.solidcraft_commands(native_spec(raw, p), p, provider=Provider)
    commands.extend(building_room_signs.solidcraft_ink_commands(source))
    for command in commands:
        if command['command'] == 'document.metadata.set':
            command['params']['values'] = {'org.solidcraftbot.building-stack': {'source_id': raw['id'], 'metric_scale_known': False, 'coordinate_meaning': {'xy': 'presentation_mm', 'z': 'assumed_mm'}, 'transport_implemented': False}}
    return commands


def source_dependencies(spec):
    spec = _spec(spec); plan, reference = templates(spec)
    paths = [SCHEMA, Path(__file__), ROOT/'scripts/building_circulation.py', ROOT/'scripts/building_roof.py', ROOT/'scripts/building_guards.py', *ground.source_dependencies(level_plan(spec, 'EG')), *ground.source_dependencies(level_plan(spec, 'KG')), ROOT/'scripts/assembly_model.py', ROOT/'model/assembly-reference.schema.json', ROOT/'scripts/room_geometry_model.py', ROOT/spec['sources']['room_geometry']['source'], *floor.source_dependencies(plan)]
    paths.append(ROOT/'scripts/lift_fittings.py')
    paths.extend([ROOT/'scripts/tube_cam_model.py', ROOT/'scripts/tube_frame_model.py', ROOT/'scripts/sample_transport_model.py'])
    if 'furnishings' in spec['sources']:
        paths.extend(furnishings.dependencies(spec['sources']['furnishings']))
        if furnishings.read(spec['sources']['furnishings']).get('atrium_seating'):
            import atrium_seating
            paths.extend(atrium_seating.dependencies())
    if 'laboratories' in spec['sources']:
        import building_laboratories
        paths.extend(building_laboratories.dependencies(spec['sources']['laboratories']))
    if 'microscopy' in spec['sources']:
        import building_microscopy
        paths.extend(building_microscopy.dependencies(spec['sources']['microscopy']))
    if 'kitchenette' in spec['sources']:
        import building_kitchenette
        paths.extend(building_kitchenette.dependencies(spec['sources']['kitchenette']))
    if 'monitor_wall' in spec['sources']:
        import foyer_monitor_wall
        paths.extend(foyer_monitor_wall.dependencies(spec['sources']['monitor_wall']))
    if 'seminar_room' in spec['sources']:
        import building_seminar
        paths.extend(building_seminar.dependencies(spec['sources']['seminar_room']))
    if 'alignment' in spec: paths.extend([ROOT/'scripts/building_alignment.py', ROOT/'model/building-alignment.schema.json'])
    if 'exterior' in spec: paths.extend([ROOT/'scripts/building_exterior.py', ROOT/'model/building-exterior.schema.json'])
    if 'doors' in spec.get('exterior',{}): paths.extend(exterior.doors.dependencies(spec['exterior']['doors']))
    if 'room_signs' in spec:
        import building_room_labels
        paths.extend([ROOT/'scripts/building_room_signs.py', ROOT/'scripts/marker_label.py', *building_room_labels.dependencies(spec)])
    if '_source' in spec: paths.insert(0, Path(spec['_source']['path']))
    return list(dict.fromkeys(paths))
