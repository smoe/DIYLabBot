"""Explicit static-data equivalence; never re-pin historical evidence or run motion."""
import ast
import copy
import gzip
import hashlib
import json
from pathlib import Path
import struct
import subprocess
import sys
import time
import types

ROOT=Path.cwd().resolve();OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'))
import building_fleet_model as model
from building_fleet_routes import Navigation
from building_fleet_runner import RouteGraph
from building_fleet_missions import MissionPlanner
from building_fleet_resources import ResourceCatalog
from building_fleet_patrol_cache import _mandatory_pins,_routes,QUALIFICATION
BASE=ROOT/'exports/building-fleet'
OLD_NAV=BASE/'patrol-5f4da9d/preparation-r1/navigation-after-graph'
OLD_GRAPH_REPORT=BASE/'patrol-5f4da9d/preparation-r1/report.json'
OLD_RESOURCE=BASE/'jerk-01c7cff/resource-catalog-r2'
WORLD=BASE/'jerk-01c7cff/walkthrough-r1'
BASE_COMMIT='586ff76a2d138e39d88463bb5d4d74457d8f6714'
started=time.perf_counter();checks={};git_bytes={}

def emit(phase,**values):print(json.dumps({'phase':phase,'elapsed_s':time.perf_counter()-started,**values}),flush=True)
def require(ok,message):
    if not ok:raise ValueError(message)
def artifact(path):
    path=Path(path);return {'path':str(path.relative_to(ROOT)),'sha256':model.digest(path),'bytes':path.stat().st_size}
def original(name):
    if name not in git_bytes:
        result=subprocess.run(['git','show',BASE_COMMIT+':'+name],cwd=ROOT,capture_output=True,check=True)
        git_bytes[name]=result.stdout
    return git_bytes[name]
def historical_pins(pins):
    output={}
    for name,digest in pins.items():
        result=subprocess.run(['git','cat-file','-e',BASE_COMMIT+':'+name],cwd=ROOT,capture_output=True)
        if result.returncode==0:
            raw=original(name);method='original_committed_bytes'
        else:
            raw=(ROOT/name).read_bytes();method='unchanged_local_original_artifact'
        require(hashlib.sha256(raw).hexdigest()==digest,'Original evidence pin not verified: '+name)
        output[name]={'sha256':digest,'verification':method}
    return output
def ast_dump(node):return ast.dump(node,include_attributes=False)
def tree(name,old=False):return ast.parse(original(name)if old else(ROOT/name).read_bytes())
def definition(module,name):return next(n for n in module.body if getattr(n,'name',None)==name)
def same_definition(path,name):
    require(ast_dump(definition(tree(path,True),name))==ast_dump(definition(tree(path),name)),path+': changed '+name)
    checks[path+':'+name]='identical_executable_AST'
def typed_hash(value):
    h=hashlib.sha256()
    def add(v):
        t=type(v)
        if v is None:h.update(b'n')
        elif t is bool:h.update(b't'if v else b'f')
        elif t is float:h.update(b'd'+struct.pack('>d',v))
        elif t in(str,int):
            b=(str(v)if t is int else v).encode();h.update((b'i'if t is int else b's')+str(len(b)).encode()+b':'+b)
        elif t in(list,tuple):
            h.update((b'l'if t is list else b'u')+str(len(v)).encode()+b':')
            for item in v:add(item)
        elif t is dict:
            h.update(b'm'+str(len(v)).encode()+b':')
            for k in sorted(v):add(k);add(v[k])
        else:raise TypeError(t)
    add(value);return h.hexdigest()
def load_original(name,module_name):
    module=types.ModuleType(module_name);module.__file__=str(ROOT/name)
    exec(compile(original(name),str(ROOT/name)+'@'+BASE_COMMIT,'exec'),module.__dict__)
    return module

require(not(OUT/'report.json').exists(),'Preserve previous derivation')
source=model.load();oldnav=model.read_json(OLD_NAV/'cache-report.json')
oldgraphreport=model.read_json(OLD_GRAPH_REPORT);oldresource=model.read_json(OLD_RESOURCE/'cache-report.json')
pins_original={**historical_pins(oldnav['source_files_sha256']),
               **historical_pins(oldresource['source_files_sha256']),
               **historical_pins(oldgraphreport['source_files_sha256_start'])}
require(oldgraphreport['source_files_sha256_start']==oldgraphreport['source_files_sha256_end'],'Old source fence failed')
same_definition('scripts/building_fleet_routes.py','Navigation')
same_definition('scripts/building_fleet_runner.py','RouteGraph')
same_definition('scripts/building_fleet_motion.py','Path')
old_clearance=tree('scripts/building_fleet_clearance.py',True);new_clearance=tree('scripts/building_fleet_clearance.py')
for module in(old_clearance,new_clearance):
    cls=definition(module,'ClearanceCertificate');cls.body=[n for n in cls.body if getattr(n,'name',None)not in('__init__','check')]
require(ast_dump(old_clearance)==ast_dump(new_clearance),'Nav-dependent native clearance operations changed')
checks['clearance_except_static_navigation_unused_certificate_init_and_check']='identical_executable_AST'
for name in('scripts/building_fleet_routes.py','scripts/building_fleet_navigation.py',
             'scripts/building_fleet_floor.py','scripts/building_fleet_support.py',
             'scripts/building_fleet_port_paths.py','scripts/building_fleet_missions.py','scripts/building_fleet_resources.py'):
    require(not any(isinstance(node,ast.Name)and node.id=='ClearanceCertificate' or isinstance(node,ast.Attribute)and node.attr=='ClearanceCertificate'for node in ast.walk(tree(name))), 'Static cache derivation may not call the changed runtime certificate: '+name)
checks['changed_runtime_certificate_not_used_for_static_data']='no_ClearanceCertificate_reference_in_static_derivation_modules'
for path in('scripts/building_fleet_navigation.py','scripts/building_fleet_floor.py',
             'scripts/building_fleet_support.py','scripts/building_fleet_geometry.py'):
    require(original(path)==(ROOT/path).read_bytes(),'Native raster/support generator changed: '+path)
checks['native_raster_floor_support_generators']='identical_original_bytes'
emit('historical_evidence_and_nav_operations_verified')

# The original pin set is admitted only after the preceding explicit provenance
# and executable-operation equivalence checks. No old report is changed.
class OriginalDataNavigation(Navigation):
    def _cache_pins(self):return oldnav['source_files_sha256']
nav=OriginalDataNavigation.from_cache(source,WORLD,OLD_NAV)
nav.__class__=Navigation
current_pins={**{name:model.digest(ROOT/name)for name in oldgraphreport['source_files_sha256_start']},**_mandatory_pins(nav)}
nav.write_cache(OUT/'navigation')
require(gzip.decompress((OLD_NAV/'navigation.json.gz').read_bytes())==
        gzip.decompress((OUT/'navigation/navigation.json.gz').read_bytes()),'New raw navigation data changed')
emit('new_navigation_cache_written',artifact=artifact(OUT/'navigation/cache-report.json'))

graph_path=ROOT/oldgraphreport['route_graph']['path']
require(artifact(graph_path)==oldgraphreport['route_graph'],'Original graph bytes changed')
data=model.read_json(graph_path)
require(data['source_files_sha256']==oldgraphreport['source_files_sha256_start']and data['qualification']==QUALIFICATION,'Original graph source binding changed')
require(ResourceCatalog.route_bank_hash(data['routes'])==data['route_bank_sha256']==oldresource['route_bank_sha256'],'Original complete route bank changed')
raw=(OLD_RESOURCE/'closure.json').read_bytes()
require(len(raw)==oldresource['bytes']and hashlib.sha256(raw).hexdigest()==oldresource['artifact_sha256'],'Original closure bytes changed')
closure=json.loads(raw)['canonical']
graph=RouteGraph(nav);planner=MissionPlanner(source,nav,graph)
for home in nav.homes.values():
    graph.add_endpoint(home['level'],home['departure_xy_mm']);graph.add_endpoint(home['level'],home['arrival_xy_mm'])
for(level,_),row in nav.inspections.items():graph.add_endpoint(level,row['points_mm'][0]);graph.add_endpoint(level,row['points_mm'][-1])
require(data['hubs']==graph.hubs and{level:{tuple(p)for p in points}for level,points in data['endpoints'].items()}==graph.endpoints,'Current source endpoints changed')
centres=_routes(data['centreline'],graph,repairs=False)
order=[(level,p,tuple(graph.hubs[level]))for level,points in graph.endpoints.items()for p in sorted(points)if p!=tuple(graph.hubs[level])]
require(set(order)==set(centres),'Current source hub connections changed')
graph.centreline={k:centres[k]for k in order};repairs=_routes(data['repairs'],graph,repairs=True)
graph.repairs={k:repairs[k]for level in graph.endpoints for k in sorted(repairs)if k[0]==level};graph.sealed=True
routes=graph.base_routes()+planner.prepared_routes()
require(ResourceCatalog.route_bank_hash(routes)==data['route_bank_sha256'],'Fresh source-derived lane/port bank changed')
emit('current_lane_and_port_bank_verified',routes=len(routes))

old_resource_module=load_original('scripts/building_fleet_resources.py','_original_resource_for_equivalence')
old_motion=load_original('scripts/building_fleet_motion.py','_original_motion_for_equivalence')
old_resource_module.Path=old_motion.Path
old_tree=tree('scripts/building_fleet_resources.py',True);new_tree=tree('scripts/building_fleet_resources.py')
old_cls=definition(old_tree,'ResourceCatalog');new_cls=definition(new_tree,'ResourceCatalog')
ignored={'__init__','_route','_cache_pins','write_cache','from_cache'}
for node in old_tree.body:
    if isinstance(node,ast.FunctionDef):
        require(ast_dump(node)==ast_dump(definition(new_tree,node.name)),'Resource predicate changed: '+node.name)
for node in old_cls.body:
    if isinstance(node,ast.FunctionDef)and node.name not in ignored:
        require(ast_dump(node)==ast_dump(definition(new_cls,node.name)),'Resource closure operation changed: '+node.name)
checks['resource_geometry_and_closure_methods']='identical_executable_AST'
def normalize_constructor(node):
    node=copy.deepcopy(node)
    node.args.kwonlyargs=[a for a in node.args.kwonlyargs if a.arg!='_validated_paths']
    node.args.kw_defaults=[None]*len(node.args.kwonlyargs)
    skip={'inputs','path_count','expected_validation','self._path_validation_source_pins','self._path_validation','self._validated_route_bank'}
    node.body=[s for s in node.body if not(isinstance(s,ast.Assign)and any(ast.unparse(t)in skip for t in s.targets))
               and not(isinstance(s,ast.If)and ast.unparse(s.test).startswith('_validated_paths'))]
    for item in ast.walk(node):
        if isinstance(item,ast.Call):item.keywords=[k for k in item.keywords if k.arg!='construct_path']
    return node
require(ast_dump(normalize_constructor(definition(old_cls,'__init__')))==ast_dump(normalize_constructor(definition(new_cls,'__init__'))),'Original full constructor geometry/closure loop changed')
def normalize_route(node):
    node=copy.deepcopy(node);node.args.kwonlyargs=[];node.args.kw_defaults=[]
    body=[]
    for s in node.body:
        body.extend(s.body if isinstance(s,ast.If)and isinstance(s.test,ast.Name)and s.test.id=='construct_path'else[s])
    node.body=body;return node
require(ast_dump(normalize_route(definition(old_cls,'_route')))==ast_dump(normalize_route(definition(new_cls,'_route'))),'Original route geometry construction changed')
checks['resource_full_constructor_and_route_geometry']='identical_AST_after_removing_only_receipt_bookkeeping_and_optin_skip'
emit('original_full_paths_constructing')
old_catalog=old_resource_module.ResourceCatalog(nav,routes,_cached_canonical=closure)
emit('current_full_paths_constructing')
catalog=ResourceCatalog(nav,routes,_cached_canonical=closure)
require(typed_hash(old_catalog.report())==typed_hash(catalog.report()),'Raw regions/aliases/rooms/guards changed')
require(len(old_catalog.paths)==len(catalog.paths)==len(routes),'Complete original path bank missing')
path_hashes=[];samples=0
for(oldlevel,a),(newlevel,b)in zip(old_catalog.paths,catalog.paths):
    require(oldlevel==newlevel,'Path floor changed')
    names=('pieces','ends','length','samples','corner_trim_caps')
    left={n:getattr(a,n)for n in names};right={n:getattr(b,n)for n in names}
    digest=typed_hash(left);require(digest==typed_hash(right),'IEEE-exact Path pieces/ends/length/samples changed')
    path_hashes.append(digest);samples+=len(a.samples)
checks['complete_path_geometry_and_samples']={'paths':len(path_hashes),'sample_intervals':samples,
    'typed_IEEE_path_hashes_sha256':typed_hash(path_hashes),'all_identical':True}
checks['resource_raw_geometry_sha256']=typed_hash(catalog.report())
catalog.write_cache(OUT/'resources',routes,validated_paths=True)
emit('new_validated_resource_cache_written',artifact=artifact(OUT/'resources/cache-report.json'))

equivalence={'format':'solidcraftbot.building-fleet-static-data-equivalence/1','passed':True,
    'base_commit':BASE_COMMIT,'original_pins_verified':pins_original,'checks':checks,
    'original_navigation':artifact(OLD_NAV/'cache-report.json'),'new_navigation':artifact(OUT/'navigation/cache-report.json'),
    'original_resource':artifact(OLD_RESOURCE/'cache-report.json'),'new_resource':artifact(OUT/'resources/cache-report.json'),
    'original_graph':artifact(OLD_GRAPH_REPORT),'original_route_bank_sha256':data['route_bank_sha256'],
    'source_files_sha256_start':current_pins,'source_files_sha256_end':{name:model.digest(ROOT/name)for name in current_pins},
    'qualification':{'static_data_equivalence_only':True,'motion_executed':False,
        'full_closure_reexecuted':False,'native_full_program_qualified':False,'hardware_executed':False},
    'scope':'Original verified static-data provenance plus unchanged executable geometry/closure operations and bit-identical freshly constructed complete Path/guard bank. Reuses original canonical closure by deterministic equivalence; no old report re-pinning or new full closure/motion qualification.',
    'previous_static_equivalence':artifact(OUT.parent/'static-r1/equivalence.json'),
    'independent_original_grid_curve_foundation':artifact(OUT.parent/'native-equivalence-r2-current/report.json'),
    'elapsed_s':time.perf_counter()-started,'checker':artifact(Path(__file__))}
require(equivalence['source_files_sha256_start']==equivalence['source_files_sha256_end'],'Current sources changed during derivation')
(OUT/'equivalence.json').write_text(json.dumps(equivalence,indent=2)+'\n')
newdata={**data,'source_files_sha256':current_pins,'world_report':artifact(WORLD/'world-build-report.json'),
    'navigation_input':artifact(OUT/'navigation/cache-report.json'),'resource_input':artifact(OUT/'resources/cache-report.json'),
    'routes':routes,'scope':'Explicit new static-data-equivalence derivation; see preparation data_equivalence artifact. No new full closure or movement claim.'}
(OUT/'route-graph.json').write_text(json.dumps(newdata,separators=(',',':'),allow_nan=False)+'\n')
report={'format':'solidcraftbot.building-fleet-static-preparation/1','passed':True,
    'source_files_sha256_start':current_pins,'source_files_sha256_end':{name:model.digest(ROOT/name)for name in current_pins},
    'route_graph':artifact(OUT/'route-graph.json'),'route_count':len(routes),
    'centreline_count':len(graph.centreline),'repair_count':len(graph.repairs),
    'engine_model_time_s':0.,'data_equivalence':artifact(OUT/'equivalence.json'),
    'qualification':{'static_preparation_only':True,'motion_executed':False,'full_fleet_qualified':False,'hardware_executed':False},
    'elapsed_s':time.perf_counter()-started}
require(report['source_files_sha256_start']==report['source_files_sha256_end'],'Source fence changed')
(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
emit('static_equivalence_ready',report=artifact(OUT/'report.json'),resources=artifact(OUT/'resources/cache-report.json'))
